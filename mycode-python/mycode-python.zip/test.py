'''
class Solution:
    def PlusOne(self, arrayD):
        
arrayD=[9,9,9,9,9]
mySolu=Solution()
result=mySolu.PlusOne(arrayD)
print(result)
'''
